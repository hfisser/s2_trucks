# S2TD

A method for automatically detecting moving trucks in Sentinel-2 remote sensing data.